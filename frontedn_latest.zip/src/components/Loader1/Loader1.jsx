import React from 'react';
import './Loader1.css';

const Loader1 = () => {
  return (
    <span className="loader1"></span> 
  );
};

export default Loader1;